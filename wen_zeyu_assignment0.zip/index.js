
console.log("Hello World");
console.log("ID: 1576772");
console.log("Email:	zwen3@stu.parkland.edu");
console.log("Reason to take this class: I haven't used Perl before and I thought it was about computer grahpics, nevertheless it's fine since I have been wanting to try out NodeJS for quite a while.");